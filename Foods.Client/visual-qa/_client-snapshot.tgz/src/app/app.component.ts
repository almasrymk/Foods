import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavigationEnd, Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { AuthService } from './core/auth.service';
import { DraftService } from './core/draft.service';
import { IconComponent } from './core/icon.component';
import { FaSelectedSheetComponent } from './pages/screens/shared/selected-sheet.component';

@Component({
  selector: 'app-root',
  imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive, IconComponent, FaSelectedSheetComponent],
  template: `
    <div class="app" [class.cms]="isCms()" [class.guest]="isGuest()" [class.menu-open]="menuOpen" [class.customer-home]="isHome()" [class.home-screen]="isHomeScreen()">
      <ng-container *ngIf="isCms(); else customer">
        <button type="button" class="cms-backdrop" *ngIf="menuOpen && !isGuest()" (click)="menuOpen = false" aria-label="إغلاق القائمة"></button>
        <aside class="side" *ngIf="!isGuest()">
          <div class="brand"><img class="logo" src="logo.png?v=2" alt="Foodapp"> لوحة الإدارة</div>
          <a routerLink="/cms/lookups" routerLinkActive="active"><app-icon name="lookups"></app-icon> البيانات المساعدة</a>
          <a routerLink="/cms/meals" routerLinkActive="active"><app-icon name="meals"></app-icon> الوجبات</a>
          <a routerLink="/cms/items" routerLinkActive="active"><app-icon name="items"></app-icon> الأكلات</a>
          <a routerLink="/cms/contents" routerLinkActive="active"><app-icon name="contents"></app-icon> المكونات</a>
          <a routerLink="/cms/users" routerLinkActive="active"><app-icon name="users"></app-icon> المستخدمين</a>
          <a routerLink="/home"><app-icon name="app"></app-icon> تطبيق العميل</a>
          <button type="button" class="ghost" (click)="auth.logout()"><app-icon name="logout"></app-icon> خروج</button>
        </aside>
        <main class="cms-main">
          <button type="button" class="cms-menu" *ngIf="!isGuest()" (click)="menuOpen = !menuOpen">
            <span class="bars" aria-hidden="true"></span>
            القائمة
          </button>
          <router-outlet></router-outlet>
        </main>
      </ng-container>
      <ng-template #customer>
        <header class="topbar" *ngIf="auth.isLoggedIn() && !isGuest() && !isHome()">
          <a class="brand" routerLink="/home"><img class="logo" src="logo.png?v=2" alt="Foodapp"></a>
          <nav class="menu">
            <a routerLink="/home" routerLinkActive="active"><app-icon name="meals"></app-icon> الرئيسية</a>
            <a routerLink="/favorites" routerLinkActive="active"><app-icon name="favorites"></app-icon> أكلاتي المفضلة</a>
            <a routerLink="/orders" routerLinkActive="active"><app-icon name="orders"></app-icon> الطلبات</a>
            <a routerLink="/builder" routerLinkActive="active"><app-icon name="builder"></app-icon> الطلب</a>
            <a routerLink="/family" routerLinkActive="active"><app-icon name="family"></app-icon> الأسرة</a>
          </nav>
          <div class="account">
            <span>{{ auth.name() }}</span>
            <button type="button" (click)="auth.logout()"><app-icon name="logout"></app-icon> خروج</button>
          </div>
        </header>
        <a *ngIf="auth.isAdmin() && !isGuest()" class="admin-fab" routerLink="/cms/meals"
           title="الإدارة" aria-label="الإدارة">
          <app-icon name="admin"></app-icon>
          <span>الإدارة</span>
        </a>
        @if (!isGuest() && !isSettings() && !isPurchaseOrder()) {
          <fa-selected-sheet />
        }
        <main class="page">
          <router-outlet></router-outlet>
        </main>
      </ng-template>
    </div>
  `
})
export class AppComponent {
  menuOpen = false;

  constructor(public auth: AuthService, public draft: DraftService, private router: Router) {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) this.menuOpen = false;
    });
  }

  isCms(): boolean {
    return this.router.url.startsWith('/cms');
  }

  isGuest(): boolean {
    const path = this.router.url.split('?')[0];
    return path === '/login' || path === '/register';
  }

  isSettings(): boolean {
    return this.router.url.split('?')[0] === '/settings';
  }

  isPurchaseOrder(): boolean {
    return /^\/orders\/[^/]+$/.test(this.router.url.split('?')[0]);
  }

  /** Customer screens that draw their own full-page mockup layout (no top bar, no page padding). */
  private static readonly SCREENS = [
    /^\/home$/, /^\/meals(\/[^/]+)?$/, /^\/cuisines$/, /^\/items\/[^/]+$/, /^\/favorites$/,
    /^\/orders$/, /^\/orders\/[^/]+$/, /^\/ingredients$/, /^\/settings$/
  ];

  isHome(): boolean {
    return this.isHomeScreen();
  }

  isHomeScreen(): boolean {
    const path = this.router.url.split('?')[0];
    return AppComponent.SCREENS.some(re => re.test(path));
  }
}
