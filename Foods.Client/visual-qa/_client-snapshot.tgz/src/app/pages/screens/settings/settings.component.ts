import { Component } from '@angular/core';
import { Location } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../../core/auth.service';
import { FaTabBarComponent } from '../shared/tab-bar.component';
import { FaLogoComponent } from '../shared/logo.component';
import { FaIconComponent } from '../shared/icon.component';
import { ABOUT_ROWS, FamilyCard, SETTINGS_COUNTRY, SETTINGS_PROFILE, familyCards } from './settings.data';

/** الإعدادات: profile, app settings, family and about (design/mockups/settings.png). */
@Component({
  selector: 'app-settings-screen',
  imports: [RouterLink, FaLogoComponent, FaTabBarComponent, FaIconComponent],
  templateUrl: './settings.component.html',
  styleUrl: './settings.component.css'
})
export class SettingsScreenComponent {
  readonly profile = SETTINGS_PROFILE;
  readonly country = SETTINGS_COUNTRY;
  readonly about = ABOUT_ROWS;
  family: FamilyCard[] = familyCards();
  lang: 'ar' | 'en' = 'ar';

  constructor(public location: Location, private auth: AuthService) {}

  remove(member: FamilyCard): void {
    this.family = this.family.filter(m => m !== member);
  }

  logout(): void {
    this.auth.logout();
  }
}
