import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from '../../../core/api.service';
import { mediaUrl } from '../../../core/environment';
import { FaTabBarComponent } from '../shared/tab-bar.component';
import { FaLogoComponent } from '../shared/logo.component';
import { FaIconComponent } from '../shared/icon.component';
import { MEAL_DETAILS } from './meal-details.data';

/** تفاصيل الأكلة: meal details (design/mockups/meal-details.png, drawn 958px wide). */
@Component({
  selector: 'app-meal-details-screen',
  imports: [FaLogoComponent, FaTabBarComponent, FaIconComponent],
  templateUrl: './meal-details.component.html',
  styleUrl: './meal-details.component.css'
})
export class MealDetailsScreenComponent implements OnInit {
  meal = { ...MEAL_DETAILS };
  qty = 1;
  favorite = false;
  busy = false;
  private itemId = '';

  constructor(
    public location: Location,
    private route: ActivatedRoute,
    private api: ApiService
  ) {}

  ngOnInit(): void {
    this.itemId = this.route.snapshot.paramMap.get('id') || '';
    if (!this.itemId) return;
    this.api.item(this.itemId).subscribe({
      next: item => {
        this.favorite = !!item.isFavorite;
        this.meal = {
          ...this.meal,
          title: item.name || this.meal.title,
          desc: item.summary || this.meal.desc,
          video: mediaUrl(item.imagePath) || this.meal.video
        };
      }
    });
  }

  step(delta: number): void {
    this.qty = Math.max(1, this.qty + delta);
  }

  toggleFavorite(): void {
    if (this.busy || !this.itemId) return;
    const next = !this.favorite;
    this.busy = true;
    const call = next ? this.api.addFavorite(this.itemId) : this.api.removeFavorite(this.itemId);
    call.subscribe({
      next: () => {
        this.favorite = next;
        this.busy = false;
      },
      error: () => { this.busy = false; }
    });
  }
}
