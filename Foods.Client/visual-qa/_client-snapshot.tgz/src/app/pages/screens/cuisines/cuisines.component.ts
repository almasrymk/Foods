import { Component, OnInit } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { ApiService } from '../../../core/api.service';
import { mediaUrl } from '../../../core/environment';
import { MealItemFilter } from '../../../core/models';
import { FaTabBarComponent } from '../shared/tab-bar.component';
import { FaLogoComponent } from '../shared/logo.component';
import { FaIconComponent } from '../shared/icon.component';

interface CuisineTile {
  id: string;
  label: string;
  count: number;
  iconKey: string;
  iconImage: string;
  color: string;
  bg: string;
}

/** Browse all cuisines — same layout idea as the meals plan screen. */
@Component({
  selector: 'app-cuisines-screen',
  imports: [RouterLink, FaLogoComponent, FaTabBarComponent, FaIconComponent],
  templateUrl: './cuisines.component.html',
  styleUrl: './cuisines.component.css'
})
export class CuisinesScreenComponent implements OnInit {
  tiles: CuisineTile[] = [];
  loading = true;

  private readonly cols = [627, 332, 35];
  private readonly rowTops = [417, 724, 1008, 1292, 1576];
  private readonly rowHeights = [283, 272, 272, 272, 272];

  constructor(private router: Router, private api: ApiService) {}

  ngOnInit(): void {
    this.api.cuisines().subscribe({
      next: filters => {
        this.tiles = (filters || [])
          .filter(chip => !!chip.id)
          .map(chip => this.toTile(chip));
        this.loading = false;
      },
      error: () => {
        this.tiles = [];
        this.loading = false;
      }
    });
  }

  open(tile: CuisineTile): void {
    this.router.navigate(['/meals', 'all'], {
      queryParams: { cuisineId: tile.id },
      state: { name: 'الكل' }
    });
  }

  left(index: number): number {
    return this.cols[index % 3];
  }

  top(index: number): number {
    const row = Math.floor(index / 3);
    return this.rowTops[row] ?? (this.rowTops[this.rowTops.length - 1] + (row - this.rowTops.length + 1) * 284);
  }

  height(index: number): number {
    return this.rowHeights[Math.floor(index / 3)] ?? this.rowHeights[this.rowHeights.length - 1];
  }

  canvasHeight(): number {
    if (!this.tiles.length) return 1100;
    const lastTop = this.top(this.tiles.length - 1);
    const lastHeight = this.height(this.tiles.length - 1);
    return Math.max(1100, lastTop + lastHeight + 80);
  }

  private toTile(chip: MealItemFilter): CuisineTile {
    const path = (chip.iconPath || '').trim();
    const isImage = path.includes('/') || path.startsWith('http');
    return {
      id: chip.id || '',
      label: chip.name || '',
      count: chip.count || 0,
      iconKey: !isImage && path ? path : this.iconName(chip.name),
      iconImage: isImage ? mediaUrl(path) : '',
      color: chip.textColor || '#2E1E12',
      bg: chip.color?.trim() || '#FFFCF9'
    };
  }

  private iconName(name: string): string {
    const value = (name || '').trim();
    if (/نباتي|نبات|فيجان|vegan/.test(value)) return 'vegan';
    if (/صحي|سلطة|دايت/.test(value)) return 'leaf';
    if (/مشوي|كباب|شيش|ستيك|مشويات/.test(value)) return 'grill';
    if (/غربي|باستا|بيتزا|برجر/.test(value)) return 'chef';
    return 'cloche';
  }
}
