import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Location } from '@angular/common';
import { FaIconComponent } from './icon.component';
import { FaLogoComponent } from './logo.component';

/**
 * FOODAPP header used by the list-style mockup screens: orange corner art, logo,
 * title between green dashes and a back button. Positions are mockup px (941 wide).
 */
@Component({
  selector: 'fa-screen-header',
  imports: [FaIconComponent, FaLogoComponent],
  template: `
    <header class="head" [style.height]="px(height)">
      <img class="corner" src="assets/screens/shared/corner.png" alt="">
      <fa-logo class="hd-logo" />
      @if (share) {
        <button type="button" class="hd-share" [style.top]="px(backY)" (click)="shareClick.emit()" aria-label="مشاركة">
          <fa-icon name="share" [weight]="2.4" />
        </button>
      }
      <button type="button" class="hd-back" [style.top]="px(backY)" (click)="location.back()" aria-label="رجوع">
        <fa-icon name="chevronLeft" [weight]="2.6" />
      </button>
      <div class="title" [style.top]="px(titleY)" [style.font-size]="px(titleSize)">
        <img class="dash flip" src="assets/screens/shared/dash.png" alt="">
        @if (heart || titleIcon) {
          <fa-icon class="title-icon" [name]="titleIcon || 'heart'" [weight]="2.2" />
        }
        <h1>{{ title }}</h1>
        <img class="dash" src="assets/screens/shared/dash.png" alt="">
      </div>
      @if (subtitle) { <p class="sub" [style.top]="px(subY)">{{ subtitle }}</p> }
    </header>
  `,
  styles: [`
    :host { display: block; }
    .head { position: relative; }
    .corner { position: absolute; left: 0; top: 0; width: calc(250 * var(--s)); height: calc(135 * var(--s)); }
    .hd-logo { position: absolute; left: calc(400 * var(--s)); top: calc(12 * var(--s)); width: calc(145 * var(--s)); height: calc(125 * var(--s)); }
    .hd-back, .hd-share {
      position: absolute; width: calc(72 * var(--s)); height: calc(70 * var(--s));
      display: grid; place-items: center; padding: 0; border: 0; cursor: pointer;
      border-radius: calc(20 * var(--s)); background: #FFFCF8 !important; color: #2E1E12;
      box-shadow: 0 calc(4 * var(--s)) calc(14 * var(--s)) rgba(120, 72, 30, .13);
      font-size: calc(34 * var(--s));
    }
    .hd-back { left: calc(818 * var(--s)); }
    .hd-share { left: calc(28 * var(--s)); }
    .title {
      position: absolute; left: 0; right: 0; transform: translateY(-50%);
      display: flex; justify-content: center; align-items: center; gap: calc(22 * var(--s));
    }
    .title h1 { margin: 0; font-size: 1em; font-weight: 800; color: #3A2412; line-height: 1.2; white-space: nowrap; display: block; }
    .title-icon { color: #F37202; font-size: calc(54 * var(--s)); margin-left: calc(-4 * var(--s)); }
    .dash { width: calc(62 * var(--s)); height: calc(22 * var(--s)); }
    .dash.flip { transform: scaleX(-1); }
    .sub {
      position: absolute; left: 0; right: 0; margin: 0; transform: translateY(-50%);
      text-align: center; font-size: calc(26 * var(--s)); font-weight: 500; color: #2E1E12;
    }
  `]
})
export class FaScreenHeaderComponent {
  @Input({ required: true }) title = '';
  @Input() subtitle = '';
  @Input() heart = false;
  /** Optional title icon (e.g. basket). Falls back to heart when heart=true. */
  @Input() titleIcon = '';
  @Input() share = false;
  @Output() shareClick = new EventEmitter<void>();
  /** Header block height and element positions, in mockup px. */
  @Input() height = 260;
  @Input() titleY = 180;
  @Input() titleSize = 50;
  @Input() backY = 155;
  @Input() subY = 233;

  constructor(public location: Location) {}

  px(v: number): string {
    return `calc(${v} * var(--s))`;
  }
}
