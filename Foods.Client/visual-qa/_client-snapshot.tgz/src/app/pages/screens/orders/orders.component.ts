import { Component } from '@angular/core';
import { FaScreenHeaderComponent } from '../shared/screen-header.component';
import { FaTabBarComponent } from '../shared/tab-bar.component';
import { FaIconComponent } from '../shared/icon.component';
import { ORDER_CHIPS, ORDER_STATUS, OrderCard, orderCards } from './orders.data';

/** الطلبات القديمة: previous orders (design/mockups/orders.png). */
@Component({
  selector: 'app-orders-screen',
  imports: [FaScreenHeaderComponent, FaTabBarComponent, FaIconComponent],
  template: `
    <div class="fa-screen" dir="rtl">
      <fa-screen-header title="الطلبات القديمة" [height]="210" [titleY]="157" [backY]="120" />
      <div class="fa-search" style="margin: calc(8 * var(--s)) calc(36 * var(--s)) 0 calc(38 * var(--s))">
        <label class="fa-search-pill"><fa-icon name="search" [weight]="2.4" />
          <input type="search" placeholder="ابحث في الطلبات القديمة..." [value]="query" (input)="query = $any($event.target).value">
        </label>
        <button type="button" class="fa-filter sq" aria-label="ترتيب"><fa-icon name="sort" [weight]="2.6" /></button>
      </div>
      <div class="fa-chips" style="margin: calc(23 * var(--s)) calc(33 * var(--s)) 0 calc(33 * var(--s))">
        @for (chip of chips; track chip.label) {
          <button type="button" class="fa-chip" style="height: calc(69 * var(--s))" [class.on]="chip.tag === tag" (click)="tag = chip.tag">
            <fa-icon [name]="chip.icon" [weight]="2" />{{ chip.label }}@if (chip.count) { ({{ chip.count }})}
          </button>
        }
      </div>
      <div class="cards">
        @for (o of shown; track o.id) {
          <article class="card" [class.open]="o.open">
            <fa-icon class="rcpt" name="receipt" [weight]="2" />
            <h3 class="code">طلب # <bdi dir="ltr">{{ o.code }}</bdi></h3>
            <span class="date">{{ o.date }}</span>
            <span class="status" [class]="'status ' + o.status"><fa-icon [name]="status[o.status].icon" [weight]="2.6" />{{ status[o.status].label }}</span>
            <button type="button" class="toggle" (click)="o.open = !o.open" [attr.aria-expanded]="o.open" aria-label="التفاصيل">
              <fa-icon [name]="o.open ? 'chevronUp' : 'chevronDown'" [weight]="2.6" />
            </button>
            @if (o.open) {
              <div class="inner">
                <h4 class="sec"><fa-icon name="cloche" [weight]="2" />الأطباق</h4>
                @for (d of o.dishes; track d.name) {
                  <div class="or-dish">
                    <img [src]="d.image" [alt]="d.name">
                    <span class="dname">{{ d.name }}</span>
                    <span class="dcount">{{ d.count }} ×</span>
                  </div>
                }
                <hr>
                <h4 class="sec"><fa-icon name="layers" [weight]="2" />المكونات</h4>
                <ul>
                  @for (l of o.ingredients; track l.name) {
                    <li><span>{{ l.name }}</span><b>{{ l.qty }}</b></li>
                  }
                </ul>
              </div>
              <div class="actions">
                <button type="button" class="details"><fa-icon name="doc" [weight]="2" />عرض التفاصيل</button>
                <button type="button" class="again"><fa-icon name="refresh" [weight]="2.4" />إعادة الطلب</button>
              </div>
            }
          </article>
        }
      </div>
      <fa-tab-bar />
    </div>
  `,
  styles: [`
    .sq { width: calc(92 * var(--s)); height: calc(82 * var(--s)); border-radius: calc(26 * var(--s)) !important; }
    .cards { display: flex; flex-direction: column; gap: calc(17 * var(--s)); margin: calc(33 * var(--s)) calc(24 * var(--s)) 0 calc(25 * var(--s)); }
    .card {
      position: relative; height: calc(102 * var(--s)); border-radius: calc(28 * var(--s));
      background: #FFFCF9; border: calc(1.5 * var(--s)) solid #F3E8DC;
      box-shadow: 0 calc(5 * var(--s)) calc(16 * var(--s)) rgba(120, 72, 30, .08);
    }
    .card.open { height: calc(547 * var(--s)); border: calc(2 * var(--s)) solid #6EA43C; border-radius: calc(30 * var(--s)); }
    .rcpt { position: absolute; right: calc(32 * var(--s)); top: calc(30 * var(--s)); font-size: calc(44 * var(--s)); color: #F37202; }
    .code { position: absolute; right: calc(95 * var(--s)); top: calc(10 * var(--s)); font-size: calc(31 * var(--s)); font-weight: 800; color: #2E1E12; white-space: nowrap; direction: rtl; }
    .date { position: absolute; right: calc(99 * var(--s)); top: calc(50 * var(--s)); font-size: calc(29 * var(--s)); font-weight: 500; color: #6B625C; }
    .status {
      position: absolute; left: calc(113 * var(--s)); top: calc(26 * var(--s)); height: calc(50 * var(--s)); padding: 0 calc(22 * var(--s));
      display: flex; align-items: center; gap: calc(10 * var(--s)); border-radius: calc(25 * var(--s));
      font-size: calc(25 * var(--s)); font-weight: 800; white-space: nowrap;
    }
    .open .status { left: calc(122 * var(--s)); height: calc(46 * var(--s)); }
    .status fa-icon { font-size: calc(30 * var(--s)); }
    .status.done { background: #E4F0D2; color: #2F7D1E; }
    .status.progress { background: #FDE9B8; color: #C47A06; }
    .status.cancelled { background: #FBDADA; color: #C62828; }
    .toggle {
      position: absolute; left: calc(22 * var(--s)); top: calc(24 * var(--s)); width: calc(54 * var(--s)); height: calc(54 * var(--s));
      border-radius: 50% !important; background: #FBF1E4 !important; color: #2E1E12 !important; display: grid; place-items: center;
      font-size: calc(32 * var(--s));
    }
    .inner {
      position: absolute; left: calc(23 * var(--s)); right: calc(24 * var(--s)); top: calc(110 * var(--s)); height: calc(333 * var(--s));
      border-radius: calc(22 * var(--s)); background: #F7F3EF; box-shadow: inset 0 calc(2 * var(--s)) calc(8 * var(--s)) rgba(120, 72, 30, .06);
    }
    .sec { position: absolute; right: calc(108 * var(--s)); display: flex; align-items: center; gap: calc(14 * var(--s));
           margin: 0; font-size: calc(28 * var(--s)); font-weight: 800; color: #E2640A; }
    .sec:first-child { top: calc(10 * var(--s)); }
    .sec fa-icon { font-size: calc(40 * var(--s)); }
    .or-dish { position: absolute; left: 0; right: 0; top: calc(33 * var(--s)); height: calc(80 * var(--s)); }
    .or-dish img { position: absolute; right: calc(7 * var(--s)); top: 0; width: calc(86 * var(--s)); height: calc(80 * var(--s)); border-radius: calc(12 * var(--s)); object-fit: cover; }
    .dname { position: absolute; right: calc(158 * var(--s)); top: calc(22 * var(--s)); font-size: calc(26 * var(--s)); font-weight: 500; color: #2E1E12; }
    .dcount { position: absolute; left: calc(30 * var(--s)); top: calc(22 * var(--s)); font-size: calc(26 * var(--s)); color: #2E1E12; direction: ltr; }
    hr { position: absolute; left: calc(14 * var(--s)); right: calc(13 * var(--s)); top: calc(127 * var(--s)); margin: 0; border: 0; height: calc(1.5 * var(--s)); background: #E2CDB5; }
    hr + .sec { top: calc(135 * var(--s)); }
    ul { position: absolute; left: calc(22 * var(--s)); right: calc(23 * var(--s)); top: calc(178 * var(--s)); margin: 0; padding: 0; list-style: none; }
    li { display: flex; align-items: center; justify-content: space-between; height: calc(46 * var(--s)); border-bottom: calc(1 * var(--s)) solid #ECE2D8;
         font-size: calc(25 * var(--s)); color: #2E1E12; }
    li:last-child { border-bottom: 0; }
    li b { width: calc(148 * var(--s)); height: calc(38 * var(--s)); display: grid; place-items: center; border-radius: calc(19 * var(--s));
           background: #EAF4D9; font-weight: 500; }
    .actions { position: absolute; left: calc(32 * var(--s)); right: calc(29 * var(--s)); top: calc(463 * var(--s)); height: calc(62 * var(--s));
               display: flex; justify-content: space-between; }
    .actions button { width: calc(400 * var(--s)); height: 100%; border-radius: calc(31 * var(--s)) !important; display: flex; align-items: center;
                      justify-content: center; gap: calc(14 * var(--s)); font-size: calc(28 * var(--s)); font-weight: 800; }
    .actions fa-icon { font-size: calc(38 * var(--s)); }
    .details { background: #E7F3D6 !important; color: #2F7D1E !important; }
    .again { background: #FFF8F1 !important; color: #E0640A !important; border: calc(2 * var(--s)) solid #E0782A !important; }
  `]
})
export class OrdersScreenComponent {
  readonly chips = ORDER_CHIPS;
  readonly status = ORDER_STATUS;
  readonly orders = orderCards();
  tag = 'all';
  query = '';

  get shown(): OrderCard[] {
    const q = this.query.trim();
    return this.orders.filter(o => !q || o.code.includes(q) || o.date.includes(q));
  }
}
