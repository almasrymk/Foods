import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { ApiService } from '../core/api.service';
import { DraftService } from '../core/draft.service';
import { mediaUrl } from '../core/environment';
import { OrderDetail, ShoppingLine } from '../core/models';
import { FaIconComponent } from './screens/shared/icon.component';
import { FaLogoComponent } from './screens/shared/logo.component';
import { FaTabBarComponent } from './screens/shared/tab-bar.component';

interface PlaceGroup {
  place: string;
  icon: string;
  lines: ShoppingLine[];
}

/** طلب الشراء — matches the purchase-order mockup. */
@Component({
  selector: 'app-order',
  imports: [RouterLink, FaIconComponent, FaLogoComponent, FaTabBarComponent],
  template: `
    <div class="fa-screen po" dir="rtl">
      <header class="top">
        <a class="round profile" routerLink="/family" aria-label="الحساب">
          <fa-icon name="person" [filled]="true" />
        </a>
        <fa-logo class="logo" />
        <a class="round bell" routerLink="/orders" aria-label="التنبيهات">
          <fa-icon name="bell" [filled]="true" />
          <b class="badge-dot">3</b>
        </a>
      </header>

      <div class="nav-row">
        <!-- RTL: first cell = right → back, title, share -->
        <button type="button" class="nav-btn" (click)="location.back()" aria-label="رجوع">
          <fa-icon name="chevronLeft" [weight]="2.6" />
        </button>
        <div class="page-title">
          <h1>طلب الشراء</h1>
          <fa-icon name="basket" [weight]="2.2" />
        </div>
        <button type="button" class="nav-btn" (click)="share()" aria-label="مشاركة">
          <fa-icon name="share" [weight]="2.4" />
        </button>
      </div>

      <div class="stage">
        <div class="hero" aria-hidden="true">
          <img src="assets/screens/purchase/hero.jpg" alt="">
        </div>

        @if (loading) {
          <div class="empty">جاري تحميل طلب الشراء...</div>
        } @else if (error) {
          <div class="empty err">{{ error }}</div>
        } @else if (order) {
          <section class="card">
            <div class="count-bar">
              <div class="count-copy">
                <b>عدد الأصناف</b>
                <fa-icon name="users" [weight]="2.2" />
              </div>
              <span class="count-num">{{ lineCount }}</span>
            </div>

            @for (group of groups; track group.place) {
              <div class="place">
                <div class="place-head">
                  <h2>{{ group.place }}</h2>
                  <fa-icon [name]="group.icon" [weight]="2.2" />
                </div>
                @for (line of group.lines; track line.contentId + ':' + line.unitId) {
                  <article class="row">
                    <img class="pic" [src]="imageOf(line)" [alt]="line.name || ''">
                    <b class="name">{{ line.name }}</b>
                    <span class="qty">{{ qtyLabel(line) }}</span>
                  </article>
                }
              </div>
            }
          </section>

          <div class="actions no-print">
            <button type="button" class="print" (click)="print()">
              طباعة
              <fa-icon name="printer" [weight]="2.2" />
            </button>
            <a class="mine" routerLink="/ingredients">
              طلباتي
              <fa-icon name="list" [weight]="2.2" />
            </a>
          </div>
        }
      </div>

      <fa-tab-bar class="no-print" />
    </div>
  `,
  styles: [`
    .po {
      background: #FDF8F3;
      padding-bottom: calc(210 * var(--s) + env(safe-area-inset-bottom));
    }

    .top {
      position: relative;
      height: calc(118 * var(--s));
      margin: 0 calc(28 * var(--s));
    }
    .round {
      position: absolute;
      top: calc(22 * var(--s));
      width: calc(78 * var(--s));
      height: calc(78 * var(--s));
      border-radius: 50%;
      background: #fff;
      box-shadow: 0 calc(4 * var(--s)) calc(14 * var(--s)) rgba(120, 72, 30, .12);
      display: grid;
      place-items: center;
      color: #4A2A12;
      font-size: calc(40 * var(--s));
      text-decoration: none;
    }
    /* Visual match to mockup: profile on left, bell on right */
    .profile { left: 0; }
    .bell { right: 0; color: #F37202; }
    .badge-dot {
      position: absolute;
      top: calc(-2 * var(--s));
      left: calc(-2 * var(--s));
      min-width: calc(28 * var(--s));
      height: calc(28 * var(--s));
      padding: 0 calc(6 * var(--s));
      border-radius: 999px;
      background: #E53935;
      color: #fff;
      font-size: calc(18 * var(--s));
      font-weight: 800;
      display: grid;
      place-items: center;
      line-height: 1;
    }
    .logo {
      position: absolute;
      left: 50%;
      top: calc(8 * var(--s));
      transform: translateX(-50%);
      width: calc(150 * var(--s));
      height: calc(112 * var(--s));
    }

    .nav-row {
      display: grid;
      grid-template-columns: calc(72 * var(--s)) 1fr calc(72 * var(--s));
      align-items: center;
      gap: calc(10 * var(--s));
      margin: calc(4 * var(--s)) calc(28 * var(--s)) 0;
    }
    .nav-btn {
      width: calc(72 * var(--s));
      height: calc(70 * var(--s));
      border-radius: calc(22 * var(--s));
      background: #FFFCF8 !important;
      color: #2E1E12 !important;
      box-shadow: 0 calc(4 * var(--s)) calc(14 * var(--s)) rgba(120, 72, 30, .12);
      display: grid;
      place-items: center;
      font-size: calc(34 * var(--s));
      cursor: pointer;
    }
    .page-title {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: calc(14 * var(--s));
      color: #F37202;
      font-size: calc(44 * var(--s));
    }
    .page-title h1 {
      margin: 0;
      font-size: calc(44 * var(--s));
      font-weight: 800;
      color: #2E1E12;
      line-height: 1;
    }

    .stage {
      position: relative;
      margin-top: calc(8 * var(--s));
    }

    .hero {
      margin: 0 calc(18 * var(--s));
      height: calc(250 * var(--s));
      border-radius: calc(36 * var(--s));
      overflow: hidden;
      background: linear-gradient(180deg, #FFF3E4, #F6EBDD);
    }
    .hero img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center 45%;
    }

    .empty {
      position: relative;
      z-index: 2;
      text-align: center;
      margin: calc(24 * var(--s));
      padding: calc(36 * var(--s));
      border-radius: calc(28 * var(--s));
      background: #FFFCF9;
      color: #8A6A4A;
      font-size: calc(28 * var(--s));
      font-weight: 700;
    }
    .empty.err { color: #C0392B; }

    .card {
      position: relative;
      z-index: 2;
      margin: calc(-72 * var(--s)) calc(24 * var(--s)) 0;
      padding: calc(18 * var(--s)) calc(18 * var(--s)) calc(14 * var(--s));
      border-radius: calc(36 * var(--s));
      background: #FFFCF9;
      box-shadow: 0 calc(12 * var(--s)) calc(30 * var(--s)) rgba(120, 72, 30, .14);
    }

    .count-bar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: calc(12 * var(--s));
      min-height: calc(70 * var(--s));
      padding: 0 calc(18 * var(--s));
      margin-bottom: calc(16 * var(--s));
      border-radius: calc(22 * var(--s));
      background: #FFE8C8;
      color: #2E1E12;
    }
    .count-num {
      min-width: calc(52 * var(--s));
      height: calc(52 * var(--s));
      border-radius: 50%;
      background: #F37202;
      color: #fff;
      display: grid;
      place-items: center;
      font-size: calc(26 * var(--s));
      font-weight: 800;
      box-shadow: 0 calc(3 * var(--s)) calc(8 * var(--s)) rgba(243, 114, 2, .28);
    }
    .count-copy {
      display: inline-flex;
      align-items: center;
      gap: calc(12 * var(--s));
      font-size: calc(30 * var(--s));
    }
    .count-copy b { font-weight: 800; }
    .count-copy fa-icon { color: #F37202; font-size: calc(38 * var(--s)); }

    .place + .place { margin-top: calc(14 * var(--s)); }
    .place-head {
      display: flex;
      align-items: center;
      justify-content: flex-start;
      gap: calc(12 * var(--s));
      min-height: calc(58 * var(--s));
      padding: 0 calc(18 * var(--s));
      margin-bottom: calc(8 * var(--s));
      border-radius: calc(18 * var(--s));
      background: #E7F2D6;
      color: #3F6F22;
    }
    .place-head h2 {
      margin: 0;
      font-size: calc(28 * var(--s));
      font-weight: 800;
    }
    .place-head fa-icon { font-size: calc(30 * var(--s)); }

    /* RTL grid: first = right → image | name | qty  (matches mockup) */
    .row {
      display: grid;
      grid-template-columns: calc(118 * var(--s)) minmax(0, 1fr) auto;
      align-items: center;
      gap: calc(14 * var(--s));
      min-height: calc(108 * var(--s));
      padding: calc(8 * var(--s)) calc(4 * var(--s));
      border-bottom: 1px solid #F1E6D8;
    }
    .place .row:last-child { border-bottom: 0; }

    .pic {
      width: calc(118 * var(--s));
      height: calc(90 * var(--s));
      border-radius: calc(20 * var(--s));
      object-fit: cover;
      background: #F7EFE4;
    }
    .name {
      font-size: calc(30 * var(--s));
      font-weight: 800;
      color: #2E1E12;
      text-align: right;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .qty {
      min-width: calc(150 * var(--s));
      height: calc(52 * var(--s));
      padding: 0 calc(14 * var(--s));
      border-radius: calc(16 * var(--s));
      background: #FFF0DC;
      color: #C45A08;
      font-size: calc(22 * var(--s));
      font-weight: 800;
      display: grid;
      place-items: center;
      white-space: nowrap;
    }

    .actions {
      display: grid;
      grid-template-columns: 1.15fr 1fr;
      gap: calc(16 * var(--s));
      margin: calc(22 * var(--s)) calc(24 * var(--s)) 0;
    }
    .print, .mine {
      height: calc(92 * var(--s));
      border-radius: calc(28 * var(--s));
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: calc(12 * var(--s));
      font-size: calc(30 * var(--s));
      font-weight: 800;
      text-decoration: none;
      border: 0;
      cursor: pointer;
      font-family: inherit;
    }
    .print {
      background: linear-gradient(90deg, #FF8A12, #F35E02) !important;
      color: #fff !important;
      box-shadow: 0 calc(6 * var(--s)) calc(16 * var(--s)) rgba(243, 94, 2, .28);
    }
    .mine {
      background: #FFE7C2 !important;
      color: #2E1E12 !important;
    }

    @media print {
      .po {
        background: #fff !important;
        padding: 0 !important;
      }
      .no-print, .top, .nav-row, .hero { display: none !important; }
      .card {
        margin: 0 !important;
        box-shadow: none !important;
        border: 1px solid #ddd;
      }
      .pic, .count-bar, .place-head, .qty, .count-num {
        print-color-adjust: exact;
        -webkit-print-color-adjust: exact;
      }
    }
  `]
})
export class OrderComponent implements OnInit {
  order: OrderDetail | null = null;
  groups: PlaceGroup[] = [];
  lineCount = 0;
  loading = true;
  error = '';

  constructor(
    private api: ApiService,
    private draft: DraftService,
    private route: ActivatedRoute,
    public location: Location
  ) {}

  ngOnInit(): void {
    this.draft.discardWorkingSelection();
    this.load(this.route.snapshot.paramMap.get('id') || '');
  }

  qtyLabel(line: ShoppingLine): string {
    const qty = Number.isInteger(line.quantity)
      ? String(line.quantity)
      : String(Math.round(line.quantity * 100) / 100);
    const unit = (line.unitName || '').trim();
    return unit ? `${qty} ${unit}` : qty;
  }

  imageOf(line: ShoppingLine): string {
    return mediaUrl(line.imagePath) || 'assets/screens/ingredients/onion.png';
  }

  print(): void {
    window.print();
  }

  share(): void {
    const title = this.order?.name || 'طلب الشراء';
    const url = typeof window !== 'undefined' ? window.location.href : '';
    if (navigator.share) {
      navigator.share({ title, url }).catch(() => undefined);
      return;
    }
    if (navigator.clipboard?.writeText && url) {
      navigator.clipboard.writeText(url).catch(() => undefined);
    }
  }

  private load(id: string): void {
    if (!id) {
      this.loading = false;
      this.error = 'الطلب غير موجود';
      return;
    }
    this.loading = true;
    this.api.order(id).subscribe({
      next: order => {
        this.order = order;
        this.groups = this.buildGroups(order.lines || []);
        this.lineCount = (order.lines || []).filter(line => line.quantity > 0).length;
        this.loading = false;
      },
      error: (err: Error) => {
        this.error = err.message || 'تعذر تحميل الطلب';
        this.loading = false;
      }
    });
  }

  private buildGroups(lines: ShoppingLine[]): PlaceGroup[] {
    const map = new Map<string, ShoppingLine[]>();
    for (const line of lines) {
      if (!(line.quantity > 0)) continue;
      const place = (line.purchasePlaceName || '').trim() || 'البقالة';
      const list = map.get(place) || [];
      list.push(line);
      map.set(place, list);
    }
    return [...map.entries()].map(([place, rows], index) => ({
      place,
      icon: index === 0 ? 'leaf' : 'basket',
      lines: rows
    }));
  }
}
