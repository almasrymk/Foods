import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { CmsService, ContentRow, NamedRow } from '../../core/cms.service';
import { CmsConfirmComponent } from './cms-confirm.component';
import { IconComponent } from '../../core/icon.component';
import { LoadingComponent } from '../../core/loading.component';
import { PhotoComponent } from '../../core/photo.component';
import { CmsPagerComponent } from './cms-pager.component';
import { Select2Component } from '../../core/select2.component';

@Component({
  selector: 'app-cms-contents',
  imports: [CommonModule, FormsModule, RouterLink, CmsConfirmComponent, IconComponent, LoadingComponent, PhotoComponent, CmsPagerComponent, Select2Component],
  template: `
    <div class="list-head">
      <h1><app-icon name="contents"></app-icon> المكونات</h1>
      <a class="primary" routerLink="new"><app-icon name="add"></app-icon> إضافة</a>
    </div>
    <div class="filters">
      <input class="cms-search" [(ngModel)]="text" (ngModelChange)="page = 0" name="text" placeholder="بحث بالاسم أو الوصف">
      <app-select2 name="category" [(ngModel)]="categoryId" (ngModelChange)="page = 0" [options]="categories" placeholder="كل التصنيفات" [allowEmpty]="true" emptyLabel="كل التصنيفات"></app-select2>
      <app-select2 name="group" [(ngModel)]="groupId" (ngModelChange)="page = 0" [options]="groups" placeholder="كل المجموعات" [allowEmpty]="true" emptyLabel="كل المجموعات"></app-select2>
      <app-select2 name="place" [(ngModel)]="placeId" (ngModelChange)="page = 0" [options]="places" placeholder="كل أماكن الشراء" [allowEmpty]="true" emptyLabel="كل أماكن الشراء"></app-select2>
      <app-select2 name="unit" [(ngModel)]="unitId" (ngModelChange)="page = 0" [options]="units" placeholder="كل الوحدات" [allowEmpty]="true" emptyLabel="كل الوحدات"></app-select2>
    </div>
    <p class="error" *ngIf="error">{{ error }}</p>
    <app-loading *ngIf="loading"></app-loading>
    <div class="table-scroll" *ngIf="!loading && shown().length">
    <table class="data-table">
      <thead>
        <tr>
          <th>الصورة</th>
          <th>الاسم</th>
          <th>التصنيف</th>
          <th>المجموعة</th>
          <th>مكان الشراء</th>
          <th>أقل وحدة</th>
          <th class="actions">إجراءات</th>
        </tr>
      </thead>
      <tbody>
      <tr *ngFor="let row of pageRows()">
        <td><app-photo [path]="row.imagePath" icon="contents" [alt]="row.name || ''"></app-photo></td>
        <td>
          <div>{{ row.name }}</div>
          <small *ngIf="row.description">{{ row.description }}</small>
        </td>
        <td>{{ nameOf(categories, row.contentCategoryId) }}</td>
        <td>{{ nameOf(groups, row.contentGroupId) }}</td>
        <td>{{ nameOf(places, row.purchasePlaceId) }}</td>
        <td>{{ leastUnit(row) }}</td>
        <td class="actions">
          <div class="row">
            <a class="text-link" [routerLink]="row.id"><app-icon name="edit"></app-icon> تعديل</a>
            <button type="button" class="ghost" (click)="pending = row"><app-icon name="delete"></app-icon> حذف</button>
          </div>
        </td>
      </tr>
      </tbody>
    </table>
    </div>
    <app-cms-pager [total]="shown().length" [page]="page" [size]="pageSize" (pageChange)="page = $event"></app-cms-pager>
    <p class="muted" *ngIf="!loading && !error && rows.length === 0">لا توجد مكونات.</p>
    <p class="muted" *ngIf="!loading && !error && rows.length && !shown().length">لا توجد نتائج.</p>
    <app-cms-confirm [name]="pending?.name || ''" (confirm)="remove()" (cancel)="pending = null"></app-cms-confirm>
  `
})
export class CmsContentsComponent implements OnInit {
  rows: ContentRow[] = [];
  categories: NamedRow[] = [];
  groups: NamedRow[] = [];
  places: NamedRow[] = [];
  units: NamedRow[] = [];
  text = '';
  categoryId = '';
  groupId = '';
  placeId = '';
  unitId = '';
  page = 0;
  readonly pageSize = 10;
  pending: ContentRow | null = null;
  error = '';
  loading = true;

  constructor(private cms: CmsService) {}

  ngOnInit(): void { this.load(); }

  load(): void {
    this.loading = true;
    this.cms.list<ContentRow>('Content').subscribe({
      next: rows => { this.rows = rows; this.loading = false; },
      error: (err: Error) => { this.error = err.message; this.loading = false; }
    });
    this.cms.list<NamedRow>('ContentCategory').subscribe({
      next: rows => this.categories = rows,
      error: (err: Error) => this.error = err.message
    });
    this.cms.list<NamedRow>('ContentGroup').subscribe({
      next: rows => this.groups = rows,
      error: (err: Error) => this.error = err.message
    });
    this.cms.list<NamedRow>('PurchasePlace').subscribe({
      next: rows => this.places = rows,
      error: (err: Error) => this.error = err.message
    });
    this.cms.list<NamedRow>('Unit').subscribe({
      next: rows => this.units = rows,
      error: (err: Error) => this.error = err.message
    });
  }

  shown(): ContentRow[] {
    const query = this.text.trim().toLowerCase();
    return this.rows.filter(row => {
      const nameOk = !query || `${row.name || ''} ${row.description || ''}`.toLowerCase().includes(query);
      const categoryOk = !this.categoryId || row.contentCategoryId === this.categoryId;
      const groupOk = !this.groupId || row.contentGroupId === this.groupId;
      const placeOk = !this.placeId || row.purchasePlaceId === this.placeId;
      const unitOk = !this.unitId || row.unitId === this.unitId;
      return nameOk && categoryOk && groupOk && placeOk && unitOk;
    });
  }

  nameOf(rows: NamedRow[], id?: string | null): string {
    return rows.find(row => row.id === id)?.name || '—';
  }

  leastUnit(row: ContentRow): string {
    const unit = this.nameOf(this.units, row.unitId);
    if (!row.miniQuantity && unit === '—') return '—';
    return `${row.miniQuantity ?? ''} ${unit === '—' ? '' : unit}`.trim();
  }

  pageRows(): ContentRow[] {
    const start = this.page * this.pageSize;
    return this.shown().slice(start, start + this.pageSize);
  }

  remove(): void {
    if (!this.pending) return;
    const id = this.pending.id;
    this.cms.remove('Content', id).subscribe({
      next: () => {
        this.pending = null;
        this.rows = this.rows.filter(row => row.id !== id);
      },
      error: (err: Error) => { this.pending = null; this.error = err.message; }
    });
  }
}
