import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { Observable } from 'rxjs';
import { CmsService, ContentRow, CountryLink, CountryRow, ItemRow, LinkRow, MealRow, NamedRow, UnitRow } from '../../core/cms.service';
import { mediaUrl } from '../../core/environment';
import { ApiService } from '../../core/api.service';
import { IconComponent } from '../../core/icon.component';
import { PhotoComponent } from '../../core/photo.component';
import { Select2Component } from '../../core/select2.component';

@Component({
  selector: 'app-cms-item-form',
  imports: [CommonModule, FormsModule, RouterLink, IconComponent, PhotoComponent, Select2Component],
  template: `
    <a class="back" routerLink="/cms/items">الرجوع للقائمة</a>
    <h1><app-icon [name]="form.id ? 'edit' : 'add'"></app-icon> {{ form.id ? 'تعديل أكلة' : 'إضافة أكلة' }}</h1>
    <p class="error" *ngIf="error">{{ error }}</p>
    <form class="panel editor" (ngSubmit)="save()">
      <div class="fields">
        <label>الاسم<input [(ngModel)]="form.name" name="name" required></label>
        <label>ملخص<input [(ngModel)]="form.summary" name="summary"></label>
        <label>التصنيف
          <app-select2 name="category" [(ngModel)]="form.itemCategoryId" [options]="categories" placeholder="اختار التصنيف" [required]="true"></app-select2>
        </label>
        <label>المطبخ
          <app-select2 name="cuisine" [(ngModel)]="form.cuisineId" [options]="cuisines" placeholder="اختار المطبخ" [allowEmpty]="true" emptyLabel="بدون مطبخ"></app-select2>
        </label>
        <label>المجموعة
          <app-select2 name="group" [(ngModel)]="form.itemGroupId" [options]="groups" placeholder="اختار المجموعة" [required]="true"></app-select2>
        </label>
        <label class="wide">طريقة العمل<textarea [(ngModel)]="form.description" name="description"></textarea></label>
      </div>
      <section>
        <h2>الصورة</h2>
        <div class="file-row">
          <app-photo [path]="form.imagePath" icon="items" alt=""></app-photo>
          <label class="file-btn">اختيار صورة<input type="file" accept="image/*" (change)="onFile($event)"></label>
        </div>
      </section>
      <section>
        <h2>الوجبات</h2>
        <div class="checks">
          <label *ngFor="let meal of meals"><input type="checkbox" [checked]="selectedMeals.has(meal.id)" (change)="toggleMeal(meal.id)"> {{ meal.name }}</label>
        </div>
      </section>
      <section>
        <h2>البلاد</h2>
        <p class="muted">الأكلة ممكن تتقدم في أكتر من بلد. اختار بلد واحدة رئيسية، واكتب الاسم والوصف بلهجة كل بلد لو مختلفين.</p>
        <div class="country" *ngFor="let link of countryLinks; let i = index">
          <app-select2 [name]="'country' + i" [(ngModel)]="link.countryId" [options]="countryChoices" placeholder="البلد"></app-select2>
          <label class="check"><input type="radio" name="primaryCountry" [checked]="link.isPrimary" (change)="markPrimary(i)"> الرئيسية</label>
          <input [(ngModel)]="link.name" [name]="'cn' + i" placeholder="الاسم باللهجة">
          <input [(ngModel)]="link.summary" [name]="'cs' + i" placeholder="الملخص باللهجة">
          <textarea [(ngModel)]="link.description" [name]="'cd' + i" placeholder="طريقة العمل باللهجة"></textarea>
          <button type="button" class="ghost" (click)="countryLinks.splice(i, 1)"><app-icon name="delete"></app-icon> حذف</button>
        </div>
        <button type="button" class="add" (click)="addCountry()"><app-icon name="add"></app-icon> بلد</button>
      </section>
      <section>
        <h2>المكونات</h2>
        <div class="line" *ngFor="let line of lines; let i = index">
          <app-select2 [name]="'c' + i" [(ngModel)]="line.contentId" [options]="contents" placeholder="المكوّن"></app-select2>
          <app-select2 [name]="'u' + i" [(ngModel)]="line.unitId" [options]="units" placeholder="الوحدة"></app-select2>
          <input type="number" min="0" step="0.01" [(ngModel)]="line.quantity" [name]="'q' + i" placeholder="الكمية">
          <button type="button" class="ghost" (click)="lines.splice(i, 1)"><app-icon name="delete"></app-icon> حذف</button>
        </div>
        <button type="button" class="add" (click)="addLine()"><app-icon name="add"></app-icon> مكون</button>
      </section>
      <section>
        <h2>خطوات</h2>
        <div class="line step" *ngFor="let step of steps; let i = index">
          <input [(ngModel)]="step.body" [name]="'s' + i" placeholder="الخطوة">
          <button type="button" class="ghost" (click)="steps.splice(i, 1)"><app-icon name="delete"></app-icon> حذف</button>
        </div>
        <button type="button" class="add" (click)="steps.push({ sort: steps.length + 1, body: '' })"><app-icon name="add"></app-icon> خطوة</button>
      </section>
      <section>
        <h2>فيديو</h2>
        <div class="line video" *ngFor="let video of videos; let i = index">
          <input [(ngModel)]="video.title" [name]="'vt' + i" placeholder="العنوان">
          <input [(ngModel)]="video.url" [name]="'vu' + i" placeholder="الرابط">
          <button type="button" class="ghost" (click)="videos.splice(i, 1)"><app-icon name="delete"></app-icon> حذف</button>
        </div>
        <button type="button" class="add" (click)="videos.push({ sort: videos.length + 1, title: '', url: '' })"><app-icon name="add"></app-icon> فيديو</button>
      </section>
      <button type="submit" class="save">حفظ</button>
    </form>
  `
})
export class CmsItemFormComponent implements OnInit {
  categories: NamedRow[] = [];
  cuisines: NamedRow[] = [];
  groups: NamedRow[] = [];
  meals: MealRow[] = [];
  contents: ContentRow[] = [];
  units: UnitRow[] = [];
  countryOptions: CountryRow[] = [];
  countryLinks: { id?: string; countryId: string; isPrimary: boolean; name: string; summary: string; description: string }[] = [];

  get countryChoices(): NamedRow[] {
    return this.countryOptions.map(country => ({
      id: country.id,
      name: country.dialect ? `${country.name} · ${country.dialect}` : country.name
    }));
  }
  originalCountries: string[] = [];
  form: ItemRow = this.empty();
  selectedMeals = new Set<string>();
  mealLinks = new Map<string, string>();
  originalLines: string[] = [];
  lines: { id?: string; contentId: string; unitId: string; quantity: number }[] = [];
  steps: { sort: number; body: string }[] = [];
  videos: { sort: number; title: string; url: string }[] = [];
  error = '';
  image = mediaUrl;

  constructor(
    private cms: CmsService,
    private api: ApiService,
    private route: ActivatedRoute,
    private router: Router) {}

  ngOnInit(): void {
    this.cms.list<NamedRow>('ItemCategory').subscribe(rows => this.categories = rows);
    this.cms.list<NamedRow>('Cuisine').subscribe(rows => this.cuisines = rows);
    this.cms.list<NamedRow>('ItemGroup').subscribe(rows => this.groups = rows);
    this.cms.list<MealRow>('Meal').subscribe(rows => this.meals = rows);
    this.cms.list<ContentRow>('Content').subscribe(rows => this.contents = rows);
    this.cms.list<UnitRow>('Unit').subscribe(rows => this.units = rows);
    this.cms.list<CountryRow>('Country').subscribe(rows => this.countryOptions = rows);
    const id = this.route.snapshot.paramMap.get('id');
    if (id) this.loadItem(id);
  }

  empty(): ItemRow {
    return { id: '', name: '', itemCategoryId: '', cuisineId: '', itemGroupId: '', summary: '', description: '', imagePath: '' };
  }

  loadItem(id: string): void {
    this.cms.get<ItemRow>('Item', id).subscribe({
      next: detail => {
        this.form = { ...detail, summary: detail.summary || '', description: detail.description || '' };
        this.loadLinks(detail.id);
      },
      error: (err: Error) => this.error = err.message
    });
  }

  loadLinks(itemId: string): void {
    this.cms.list<LinkRow>('ItemMeal', { ItemId: itemId }).subscribe(rows => {
      this.selectedMeals = new Set(rows.map(row => row.mealId || '').filter(Boolean));
      this.mealLinks = new Map(rows.filter(row => row.mealId).map(row => [row.mealId as string, row.id]));
    });
    this.cms.list<LinkRow>('ItemContent', { ItemId: itemId }).subscribe(rows => {
      this.lines = rows.map(row => ({ id: row.id, contentId: row.contentId || '', unitId: row.unitId || '', quantity: row.quantity || 0 }));
      this.originalLines = this.lines.map(line => line.id).filter((lineId): lineId is string => !!lineId);
    });
    this.cms.list<CountryLink>('ItemCountry', { ItemId: itemId }).subscribe(rows => {
      this.countryLinks = rows.map(row => ({
        id: row.id,
        countryId: row.countryId,
        isPrimary: row.isPrimary,
        name: row.name || '',
        summary: row.summary || '',
        description: row.description || ''
      }));
      this.originalCountries = this.countryLinks.map(link => link.id).filter((linkId): linkId is string => !!linkId);
    });
    this.api.item(itemId).subscribe({
      next: detail => {
        this.steps = (detail.steps || []).map(step => ({ sort: step.sort, body: step.body || '' }));
        this.videos = (detail.videos || []).map(video => ({ sort: video.sort, title: video.title || '', url: video.url || '' }));
      },
      error: () => { this.steps = []; this.videos = []; }
    });
  }

  toggleMeal(id: string): void {
    if (this.selectedMeals.has(id)) this.selectedMeals.delete(id);
    else this.selectedMeals.add(id);
    this.selectedMeals = new Set(this.selectedMeals);
  }

  addCountry(): void {
    this.countryLinks.push({
      countryId: this.countryOptions[0]?.id || '',
      isPrimary: this.countryLinks.length === 0,
      name: this.form.name || '',
      summary: this.form.summary || '',
      description: this.form.description || ''
    });
  }

  markPrimary(index: number): void {
    this.countryLinks.forEach((link, i) => link.isPrimary = i === index);
  }

  addLine(): void {
    this.lines.push({ contentId: this.contents[0]?.id || '', unitId: this.units[0]?.id || '', quantity: 1 });
  }

  onFile(event: Event): void {
    const file = (event.target as HTMLInputElement).files?.[0];
    if (!file) return;
    this.cms.upload(file).subscribe({
      next: path => this.form.imagePath = path,
      error: (err: Error) => this.error = err.message
    });
  }

  save(): void {
    const picked = this.countryLinks.filter(link => link.countryId);
    if (picked.length === 0) { this.error = 'حدد بلد واحدة على الأقل'; return; }
    if (new Set(picked.map(link => link.countryId)).size !== picked.length) { this.error = 'البلد متكررة على الأكلة'; return; }
    if (picked.filter(link => link.isPrimary).length !== 1) { this.error = 'اختار بلد رئيسية واحدة'; return; }
    this.error = '';
    const body = {
      id: this.form.id,
      name: this.form.name,
      itemCategoryId: this.form.itemCategoryId,
      cuisineId: this.form.cuisineId || null,
      itemGroupId: this.form.itemGroupId,
      summary: this.form.summary || null,
      description: this.form.description || null,
      imagePath: this.form.imagePath || null
    };
    const done = (id: string) => this.afterSave(id);
    if (this.form.id) this.cms.update('Item', body).subscribe({ next: () => done(this.form.id), error: (err: Error) => this.error = err.message });
    else this.cms.create('Item', body).subscribe({ next: id => done(id), error: (err: Error) => this.error = err.message });
  }

  afterSave(itemId: string): void {
    const mealCalls: Observable<unknown>[] = [];
    for (const mealId of this.selectedMeals) {
      if (!this.mealLinks.has(mealId)) mealCalls.push(this.cms.create('ItemMeal', { itemId, mealId }));
    }
    for (const [mealId, linkId] of this.mealLinks) {
      if (!this.selectedMeals.has(mealId)) mealCalls.push(this.cms.remove('ItemMeal', linkId));
    }
    const kept = new Set(this.lines.filter(line => line.id).map(line => line.id as string));
    const contentCalls: Observable<unknown>[] = [
      ...this.lines.filter(line => line.contentId && line.unitId && !line.id).map(line => this.cms.create('ItemContent', { itemId, contentId: line.contentId, unitId: line.unitId, quantity: Number(line.quantity) })),
      ...this.lines.filter(line => line.id && line.contentId && line.unitId).map(line => this.cms.update('ItemContent', { id: line.id, itemId, contentId: line.contentId, unitId: line.unitId, quantity: Number(line.quantity) })),
      ...this.originalLines.filter(id => !kept.has(id)).map(id => this.cms.remove('ItemContent', id))
    ];
    const keptCountries = new Set(this.countryLinks.filter(link => link.id).map(link => link.id as string));
    const countryCalls: Observable<unknown>[] = [
      ...this.countryLinks.filter(link => link.countryId && !link.id).map(link => this.cms.create('ItemCountry', { itemId, countryId: link.countryId, isPrimary: link.isPrimary, name: link.name || null, summary: link.summary || null, description: link.description || null })),
      ...this.countryLinks.filter(link => link.id && link.countryId).map(link => this.cms.update('ItemCountry', { id: link.id, itemId, countryId: link.countryId, isPrimary: link.isPrimary, name: link.name || null, summary: link.summary || null, description: link.description || null })),
      ...this.originalCountries.filter(id => !keptCountries.has(id)).map(id => this.cms.remove('ItemCountry', id))
    ];
    const leave = () => this.router.navigateByUrl('/cms/items');
    this.cms.saveRecipe(itemId, this.steps.map((step, index) => ({ sort: index + 1, body: step.body })), this.videos.map((video, index) => ({ sort: index + 1, title: video.title, url: video.url }))).subscribe({
      next: () => {
        const jobs = [...mealCalls, ...contentCalls, ...countryCalls];
        if (jobs.length === 0) { leave(); return; }
        let pending = jobs.length;
        jobs.forEach(call => call.subscribe({
          next: () => { if (--pending <= 0) leave(); },
          error: (err: Error) => this.error = err.message
        }));
      },
      error: (err: Error) => this.error = err.message
    });
  }
}
