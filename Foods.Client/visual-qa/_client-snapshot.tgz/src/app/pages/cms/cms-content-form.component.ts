import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { CmsService, ContentRow, NamedRow, UnitRow } from '../../core/cms.service';
import { mediaUrl } from '../../core/environment';
import { IconComponent } from '../../core/icon.component';
import { PhotoComponent } from '../../core/photo.component';
import { Select2Component } from '../../core/select2.component';

@Component({
  selector: 'app-cms-content-form',
  imports: [CommonModule, FormsModule, RouterLink, IconComponent, PhotoComponent, Select2Component],
  template: `
    <a class="back" routerLink="/cms/contents">الرجوع للقائمة</a>
    <h1><app-icon [name]="form.id ? 'edit' : 'add'"></app-icon> {{ form.id ? 'تعديل مكوّن' : 'إضافة مكوّن' }}</h1>
    <p class="error" *ngIf="error">{{ error }}</p>
    <form class="panel editor" (ngSubmit)="save()">
      <div class="fields">
        <label>الاسم<input [(ngModel)]="form.name" name="name" required></label>
        <label>أقل كمية<input type="number" step="0.01" [(ngModel)]="form.miniQuantity" name="mini"></label>
        <label>التصنيف
          <app-select2 name="category" [(ngModel)]="form.contentCategoryId" [options]="categories" placeholder="اختار التصنيف"></app-select2>
        </label>
        <label>المجموعة
          <app-select2 name="group" [(ngModel)]="form.contentGroupId" [options]="groups" placeholder="اختار المجموعة"></app-select2>
        </label>
        <label>الوحدة
          <app-select2 name="unit" [(ngModel)]="form.unitId" [options]="units" placeholder="اختار الوحدة"></app-select2>
        </label>
        <label>مكان الشراء
          <app-select2 name="place" [(ngModel)]="form.purchasePlaceId" [options]="places" placeholder="بدون" [allowEmpty]="true" emptyLabel="بدون"></app-select2>
        </label>
      </div>
      <section>
        <h2>الصورة</h2>
        <div class="file-row">
          <app-photo [path]="form.imagePath" icon="contents" alt=""></app-photo>
          <label class="file-btn">اختيار صورة<input type="file" accept="image/*" (change)="onFile($event)"></label>
        </div>
      </section>
      <button type="submit" class="save">حفظ</button>
    </form>
  `
})
export class CmsContentFormComponent implements OnInit {
  categories: NamedRow[] = [];
  groups: NamedRow[] = [];
  units: UnitRow[] = [];
  places: NamedRow[] = [];
  form: ContentRow = { id: '', name: '', contentCategoryId: '', contentGroupId: '', unitId: '', miniQuantity: 1, imagePath: '', purchasePlaceId: null };
  error = '';
  image = mediaUrl;

  constructor(private cms: CmsService, private route: ActivatedRoute, private router: Router) {}

  ngOnInit(): void {
    this.cms.list<NamedRow>('ContentCategory').subscribe(rows => this.categories = rows);
    this.cms.list<NamedRow>('ContentGroup').subscribe(rows => this.groups = rows);
    this.cms.list<UnitRow>('Unit').subscribe(rows => this.units = rows);
    this.cms.list<NamedRow>('PurchasePlace').subscribe(rows => this.places = rows);
    const id = this.route.snapshot.paramMap.get('id');
    if (!id) return;
    this.cms.get<ContentRow>('Content', id).subscribe({
      next: row => this.form = { ...row },
      error: (err: Error) => this.error = err.message
    });
  }

  onFile(event: Event): void {
    const file = (event.target as HTMLInputElement).files?.[0];
    if (!file) return;
    this.cms.upload(file).subscribe({
      next: path => this.form.imagePath = path,
      error: (err: Error) => this.error = err.message
    });
  }

  save(): void {
    const body = {
      id: this.form.id,
      name: this.form.name,
      contentCategoryId: this.form.contentCategoryId,
      contentGroupId: this.form.contentGroupId,
      unitId: this.form.unitId,
      miniQuantity: Number(this.form.miniQuantity),
      imagePath: this.form.imagePath || null,
      purchasePlaceId: this.form.purchasePlaceId || null
    };
    const done = () => this.router.navigateByUrl('/cms/contents');
    const fail = (err: Error) => this.error = err.message;
    if (this.form.id) this.cms.update('Content', body).subscribe({ next: done, error: fail });
    else this.cms.create('Content', body).subscribe({ next: done, error: fail });
  }
}
