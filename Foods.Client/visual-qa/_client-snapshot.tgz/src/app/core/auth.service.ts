import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { tap } from 'rxjs/operators';
import { ApiService } from './api.service';
import { AuthUser, FamilyMemberInput } from './models';

@Injectable({ providedIn: 'root' })
export class AuthService {
  constructor(private api: ApiService, private router: Router) {}

  token(): string | null {
    return localStorage.getItem('foods.token');
  }

  name(): string {
    return localStorage.getItem('foods.name') || '';
  }

  isLoggedIn(): boolean {
    return !!this.token();
  }

  isAdmin(): boolean {
    return localStorage.getItem('foods.role') === 'Admin';
  }

  login(userName: string, password: string) {
    return this.api.login(userName, password).pipe(tap(user => this.store(user)));
  }

  register(name: string, userName: string, password: string, countryId: string, family: FamilyMemberInput[]) {
    return this.api.register(name, userName, password, countryId, family).pipe(tap(user => this.store(user)));
  }

  logout(): void {
    localStorage.removeItem('foods.token');
    localStorage.removeItem('foods.name');
    localStorage.removeItem('foods.role');
    this.router.navigateByUrl('/login');
  }

  private store(user: AuthUser): void {
    localStorage.setItem('foods.token', user.token);
    localStorage.setItem('foods.name', user.name);
    if (user.role === 'Admin') localStorage.setItem('foods.role', 'Admin');
    else localStorage.removeItem('foods.role');
  }
}
