import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { environment } from './environment';
import { ApiResult } from './models';

export interface NamedRow {
  id: string;
  name?: string | null;
  iconPath?: string | null;
  color?: string | null;
  textColor?: string | null;
}

export interface UnitRow extends NamedRow {
  nickName?: string | null;
  basicQuantity: number;
  beDivided: boolean;
}

export interface UserRow extends NamedRow {
  userName?: string | null;
  role?: string | null;
  countryId?: string | null;
  countryName?: string | null;
  dialect?: string | null;
}

export interface CountryRow extends NamedRow {
  dialect?: string | null;
}

export interface CountryLink {
  id: string;
  itemId: string;
  countryId: string;
  isPrimary: boolean;
  name?: string | null;
  summary?: string | null;
  description?: string | null;
}

export interface MealRow extends NamedRow {
  description?: string | null;
  imagePath?: string | null;
  iconPath?: string | null;
  color?: string | null;
  textColor?: string | null;
  sort?: number | null;
}

export interface CuisineRow extends NamedRow {
  iconPath?: string | null;
  color?: string | null;
  textColor?: string | null;
  sort?: number | null;
}

export interface ItemRow extends NamedRow {
  imagePath?: string | null;
  itemCategoryId?: string;
  cuisineId?: string | null;
  itemGroupId?: string;
  summary?: string | null;
  description?: string | null;
}

export interface ContentRow extends NamedRow {
  contentCategoryId: string;
  contentGroupId: string;
  unitId: string;
  miniQuantity: number;
  imagePath?: string | null;
  purchasePlaceId?: string | null;
  description?: string | null;
}

export interface LinkRow {
  id: string;
  itemId: string;
  mealId?: string;
  contentId?: string;
  unitId?: string;
  quantity?: number;
}

@Injectable({ providedIn: 'root' })
export class CmsService {
  constructor(private http: HttpClient) {}

  list<T>(controller: string, params?: Record<string, string>): Observable<T[]> {
    return this.http.get<ApiResult<T[]>>(`${environment.apiUrl}/${controller}/GetList`, { params }).pipe(
      map(result => this.unwrap(result) || []),
      catchError(error => this.fail(error))
    );
  }

  get<T>(controller: string, id: string): Observable<T> {
    return this.http.get<ApiResult<T>>(`${environment.apiUrl}/${controller}/GetById`, { params: { Id: id } }).pipe(
      map(result => this.unwrap(result)),
      catchError(error => this.fail(error))
    );
  }

  create(controller: string, body: unknown): Observable<string> {
    return this.http.post<ApiResult<{ id?: string } | string>>(`${environment.apiUrl}/${controller}/Create`, body).pipe(
      map(result => {
        const value = this.unwrap(result);
        if (typeof value === 'string') return value;
        return value?.id || '';
      }),
      catchError(error => this.fail(error))
    );
  }

  update(controller: string, body: unknown): Observable<void> {
    return this.http.put<ApiResult<unknown>>(`${environment.apiUrl}/${controller}/Update`, body).pipe(
      map(result => { this.unwrap(result); }),
      catchError(error => this.fail(error))
    );
  }

  remove(controller: string, id: string): Observable<void> {
    return this.http.delete<ApiResult<unknown>>(`${environment.apiUrl}/${controller}/Delete`, { params: { Id: id } }).pipe(
      map(result => { this.unwrap(result); }),
      catchError(error => this.fail(error))
    );
  }

  saveRecipe(itemId: string, steps: { sort: number; body: string }[], videos: { sort: number; title: string; url: string }[]): Observable<void> {
    return this.http.put<ApiResult<string>>(`${environment.apiUrl}/ItemRecipe/Save`, { itemId, steps, videos }).pipe(
      map(result => { this.unwrap(result); }),
      catchError(error => this.fail(error))
    );
  }

  upload(file: File): Observable<string> {
    const data = new FormData();
    data.append('file', file);
    return this.http.post<{ path: string }>(`${environment.apiUrl}/files/image`, data).pipe(
      map(result => result.path),
      catchError(error => this.fail(error))
    );
  }

  private unwrap<T>(result: ApiResult<T>): T {
    if (result && (result.statusCode === 200 || result.statusCode === 0 || String(result.statusCode) === 'OK')) return result.response as T;
    throw new Error((result?.errors || ['حدث خطأ']).join('، '));
  }

  private fail(error: { error?: { errors?: string[] | Record<string, string[]> }; message?: string }) {
    const raw = error?.error?.errors;
    const message = Array.isArray(raw) ? raw.join('، ') : error?.message || 'تعذر الاتصال بالخادم';
    return throwError(() => new Error(message));
  }
}
