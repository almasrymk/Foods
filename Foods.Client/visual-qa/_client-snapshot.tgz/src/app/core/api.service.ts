import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { environment } from './environment';
import {
  ApiResult,
  AuthUser,
  ItemCard,
  ItemDetail,
  FamilyMember,
  FamilyMemberInput,
  MealCard,
  MealItemFilter,
  OrderDetail,
  OrderListItem,
  Profile,
  SelectedItem,
  ShoppingLine
} from './models';

@Injectable({ providedIn: 'root' })
export class ApiService {
  constructor(private http: HttpClient) {}

  login(userName: string, password: string): Observable<AuthUser> {
    return this.post<AuthUser>('/Auth/Login', { userName, password });
  }

  register(name: string, userName: string, password: string, countryId: string, family: FamilyMemberInput[]): Observable<AuthUser> {
    return this.post<AuthUser>('/Auth/Register', { name, userName, password, imagePath: null, countryId, family });
  }

  countries(): Observable<{ id: string; name?: string | null; dialect?: string | null }[]> {
    return this.get('/Auth/Countries');
  }

  profile(): Observable<Profile> {
    return this.get<Profile>('/customer/profile');
  }

  saveCountry(countryId: string): Observable<Profile> {
    return this.http.put<ApiResult<Profile>>(`${environment.apiUrl}/customer/country`, { countryId }).pipe(
      map(result => this.unwrap(result)),
      catchError(error => this.fail(error))
    );
  }

  meals(): Observable<MealCard[]> {
    return this.get<MealCard[]>('/customer/meals');
  }

  mealFilters(mealId: string): Observable<MealItemFilter[]> {
    return this.get<MealItemFilter[]>(`/customer/meals/${mealId}/filters`);
  }

  cuisines(): Observable<MealItemFilter[]> {
    return this.get<MealItemFilter[]>('/customer/cuisines');
  }

  favoriteFilters(): Observable<MealItemFilter[]> {
    return this.get<MealItemFilter[]>('/customer/favorites/filters');
  }

  suggested(text = '', cuisineId?: string | null, skip = 0, take = 8): Observable<ItemCard[]> {
    const params = new URLSearchParams();
    if (text) params.set('text', text);
    if (cuisineId) params.set('cuisineId', cuisineId);
    if (skip) params.set('skip', String(skip));
    if (take) params.set('take', String(take));
    const query = params.toString() ? `?${params.toString()}` : '';
    return this.get<ItemCard[]>(`/customer/suggested${query}`);
  }

  items(mealId: string, text: string, cuisineId?: string | null, skip = 0, take?: number | null): Observable<ItemCard[]> {
    const params = new URLSearchParams();
    if (text) params.set('text', text);
    if (cuisineId) params.set('cuisineId', cuisineId);
    if (skip) params.set('skip', String(skip));
    if (take != null) params.set('take', String(take));
    const query = params.toString() ? `?${params.toString()}` : '';
    return this.get<ItemCard[]>(`/customer/meals/${mealId}/items${query}`);
  }

  menuItems(text = '', cuisineId?: string | null, skip = 0, take?: number | null): Observable<ItemCard[]> {
    const params = new URLSearchParams();
    if (text) params.set('text', text);
    if (cuisineId) params.set('cuisineId', cuisineId);
    if (skip) params.set('skip', String(skip));
    if (take != null) params.set('take', String(take));
    const query = params.toString() ? `?${params.toString()}` : '';
    return this.get<ItemCard[]>(`/customer/menu-items${query}`);
  }

  item(id: string): Observable<ItemDetail> {
    return this.get<ItemDetail>(`/customer/items/${id}`);
  }

  addFavorite(id: string): Observable<boolean> {
    return this.post<boolean>(`/customer/items/${id}/favorite`, {});
  }

  removeFavorite(id: string): Observable<boolean> {
    return this.http.delete<ApiResult<boolean>>(`${environment.apiUrl}/customer/items/${id}/favorite`).pipe(
      map(result => this.unwrap(result)),
      catchError(error => this.fail(error))
    );
  }

  favorites(text = '', cuisineId?: string | null, skip = 0, take?: number | null): Observable<ItemCard[]> {
    const params = new URLSearchParams();
    if (text) params.set('text', text);
    if (cuisineId) params.set('cuisineId', cuisineId);
    if (skip) params.set('skip', String(skip));
    if (take != null) params.set('take', String(take));
    const query = params.toString() ? `?${params.toString()}` : '';
    return this.get<ItemCard[]>(`/customer/favorites${query}`);
  }

  family(): Observable<FamilyMember[]> {
    return this.get<FamilyMember[]>('/customer/family');
  }

  saveFamily(members: FamilyMemberInput[]): Observable<FamilyMember[]> {
    return this.http.put<ApiResult<FamilyMember[]>>(`${environment.apiUrl}/customer/family`, members).pipe(
      map(result => this.unwrap(result)),
      catchError(error => this.fail(error))
    );
  }

  calculate(items: SelectedItem[]): Observable<ShoppingLine[]> {
    return this.post<ShoppingLine[]>('/customer/orders/calculate', items.map(item => ({
      itemId: item.itemId,
      repeatCount: item.repeatCount,
      peopleCount: item.peopleCount
    })));
  }

  orders(): Observable<OrderListItem[]> {
    return this.get<OrderListItem[]>('/customer/orders');
  }

  order(id: string): Observable<OrderDetail> {
    return this.get<OrderDetail>(`/customer/orders/${id}`);
  }

  saveOrder(
    id: string | null,
    name: string,
    date: string,
    notes: string,
    items: SelectedItem[],
    lines: ShoppingLine[],
    confirm = false
  ): Observable<string> {
    const body = {
      id,
      name,
      date,
      notes,
      confirm,
      items: items.map(item => ({
        itemId: item.itemId,
        repeatCount: item.repeatCount,
        peopleCount: item.peopleCount
      })),
      lines: lines.map(line => ({
        contentId: line.contentId,
        unitId: line.unitId,
        quantity: line.quantity
      }))
    };
    // Confirmed purchase orders are always created as a new record.
    if (id && !confirm) {
      return this.http.put<ApiResult<string>>(`${environment.apiUrl}/customer/orders/${id}`, body).pipe(
        map(result => this.unwrap(result)),
        catchError(error => this.fail(error))
      );
    }
    return this.post<string>('/customer/orders', body);
  }

  reorder(id: string): Observable<string> {
    return this.post<string>(`/customer/orders/${id}/reorder`, {});
  }

  private get<T>(path: string): Observable<T> {
    return this.http.get<ApiResult<T>>(`${environment.apiUrl}${path}`).pipe(
      map(result => this.unwrap(result)),
      catchError(error => this.fail(error))
    );
  }

  private post<T>(path: string, body: unknown): Observable<T> {
    return this.http.post<ApiResult<T>>(`${environment.apiUrl}${path}`, body).pipe(
      map(result => this.unwrap(result)),
      catchError(error => this.fail(error))
    );
  }

  private unwrap<T>(result: ApiResult<T>): T {
    if (result?.response != null && (result.statusCode === 200 || result.statusCode === 0))
      return result.response;
    throw new Error((result?.errors || ['حدث خطأ']).join('، '));
  }

  private fail(error: { error?: ApiResult<unknown>; message?: string }) {
    const message = error?.error?.errors?.join('، ') || error?.message || 'تعذر الاتصال بالخادم';
    return throwError(() => new Error(message));
  }
}
