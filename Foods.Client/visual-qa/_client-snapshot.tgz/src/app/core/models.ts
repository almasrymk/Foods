export interface ApiResult<T> {
  statusCode: number;
  response: T | null;
  errors: string[] | null;
}

export interface AuthUser {
  id: string;
  name: string;
  userName: string;
  imagePath?: string | null;
  token: string;
  role?: string | null;
}

export interface Profile {
  countryId?: string | null;
  countryName?: string | null;
  dialect?: string | null;
}

export interface FamilyMemberInput {
  name: string;
  age: number;
}

export interface FamilyMember {
  id: string;
  name?: string | null;
  age: number;
}

export interface MealCard {
  id: string;
  name?: string | null;
  description?: string | null;
  imagePath?: string | null;
  iconPath?: string | null;
  color?: string | null;
  textColor?: string | null;
  sort?: number | null;
}

export interface ItemCard {
  id: string;
  name?: string | null;
  summary?: string | null;
  imagePath?: string | null;
  isFavorite: boolean;
  countryName?: string | null;
  dialect?: string | null;
  categoryId?: string | null;
  categoryName?: string | null;
  cuisineId?: string | null;
  cuisineName?: string | null;
}

export interface MealItemFilter {
  id?: string | null;
  name: string;
  count: number;
  iconPath?: string | null;
  color?: string | null;
  textColor?: string | null;
}

export interface ItemIngredient {
  contentId: string;
  name?: string | null;
  imagePath?: string | null;
  unitId: string;
  unitName?: string | null;
  quantity: number;
  purchasePlaceId?: string | null;
  purchasePlaceName?: string | null;
}

export interface ItemStep {
  sort: number;
  body?: string | null;
}

export interface ItemVideo {
  sort: number;
  title?: string | null;
  url?: string | null;
}

export interface ItemDetail {
  id: string;
  name?: string | null;
  summary?: string | null;
  description?: string | null;
  imagePath?: string | null;
  isFavorite: boolean;
  countryName?: string | null;
  dialect?: string | null;
  ingredients: ItemIngredient[];
  steps: ItemStep[];
  videos: ItemVideo[];
}

export interface SelectedItem {
  itemId: string;
  name: string;
  imagePath?: string | null;
  repeatCount: number;
  peopleCount: number | null;
}

export interface ShoppingLine {
  contentId: string;
  name?: string | null;
  imagePath?: string | null;
  purchasePlaceId?: string | null;
  purchasePlaceName?: string | null;
  unitId: string;
  unitName?: string | null;
  quantity: number;
}

/** 0 draft, 1 temporary save (حفظ مؤقت), 2 confirmed (محفوظ). */
export type OrderStatusCode = 0 | 1 | 2;

export interface OrderListItem {
  id: string;
  name?: string | null;
  date: string;
  status?: OrderStatusCode | number;
}

export interface OrderItem {
  itemId: string;
  name?: string | null;
  imagePath?: string | null;
  repeatCount: number;
  peopleCount?: number | null;
}

export interface OrderDetail {
  id: string;
  name?: string | null;
  date: string;
  notes?: string | null;
  status?: OrderStatusCode | number;
  items: OrderItem[];
  lines: ShoppingLine[];
}
